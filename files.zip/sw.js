// Service worker: guarda los archivos de la app en caché
// para que funcione sin conexión después de la primera visita.
const CACHE = 'calc-tomate-v1'; // cambia a v2, v3... cuando actualices la app
const ARCHIVOS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

// Al instalar: descarga y guarda todos los archivos
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ARCHIVOS))
  );
  self.skipWaiting();
});

// Al activar: borra cachés de versiones anteriores
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(claves =>
      Promise.all(claves.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// En cada petición: responde desde la caché; si no está, va a internet
self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(resp => resp || fetch(e.request))
  );
});
